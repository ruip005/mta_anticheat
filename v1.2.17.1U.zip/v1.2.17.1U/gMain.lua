--[[

  ______              __      __            __                             __     
 /      \            |  \    |  \          |  \                           |  \    
|  $$$$$$\ _______  _| $$_    \$$  _______ | $$____    ______    ______  _| $$_   
| $$__| $$|       \|   $$ \  |  \ /       \| $$    \  /      \  |      \|   $$ \  
| $$    $$| $$$$$$$\\$$$$$$  | $$|  $$$$$$$| $$$$$$$\|  $$$$$$\  \$$$$$$\\$$$$$$  
| $$$$$$$$| $$  | $$ | $$ __ | $$| $$      | $$  | $$| $$    $$ /      $$ | $$ __ 
| $$  | $$| $$  | $$ | $$|  \| $$| $$_____ | $$  | $$| $$$$$$$$|  $$$$$$$ | $$|  \
| $$  | $$| $$  | $$  \$$  $$| $$ \$$     \| $$  | $$ \$$     \ \$$    $$  \$$  $$
 \$$   \$$ \$$   \$$   \$$$$  \$$  \$$$$$$$ \$$   \$$  \$$$$$$$  \$$$$$$$   \$$$$ 
                                                                                                                  
           __       __   ______    ______   _______  
          |  \  _  |  \ /      \  /      \ |       \ 
 __    __ | $$ / \ | $$|  $$$$$$\|  $$$$$$\| $$$$$$$\
|  \  |  \| $$/  $\| $$ \$$__| $$ \$$__| $$| $$  | $$
| $$  | $$| $$  $$$\ $$  |     $$  |     $$| $$  | $$
| $$  | $$| $$ $$\$$\$$ __\$$$$$\ __\$$$$$\| $$  | $$
| $$__/ $$| $$$$  \$$$$|  \__| $$|  \__| $$| $$__/ $$
 \$$    $$| $$$    \$$$ \$$    $$ \$$    $$| $$    $$
  \$$$$$$  \$$      \$$  \$$$$$$   \$$$$$$  \$$$$$$$ 
                                                     
                                                                                                       
ᴛɪʀᴀʀ ᴘʀɪɴᴛ ᴅᴀ ᴛᴇʟᴀ ᴅᴏ ᴊᴏɢᴀᴅᴏʀ.
ʟᴏɢ ᴅɪsᴄᴏʀᴅ.
ɢᴜᴀʀᴅᴀ ғᴏᴛᴏ ᴅᴀ ᴛᴇʟᴀ ᴅᴏ ᴊᴏɢᴀᴅᴏʀ.
ᴏʙʀɪɢᴀʀ ᴏ ᴊᴏɢᴀᴅᴏʀ ᴀ ᴀᴛɪᴠᴀʀ ᴏ sᴄʀᴇᴇɴsʜᴀʀᴇ ᴘᴀʀᴀ ᴇɴᴛʀᴀʀ ɴᴏ sᴇʀᴠɪᴅᴏʀ.
ᴀᴠɪsᴏ ᴅᴇ ᴀʙʀɪʀ ᴇ ғᴇᴄʜᴀʀ ᴍᴇɴᴜ ᴅᴇ ᴄʜᴇᴀᴛ.
ᴠᴇʀ ᴄᴏᴍᴀɴᴅᴏs ᴅᴇ ᴍᴏᴅs ᴄᴏᴍᴘɪʟᴀᴅᴏs.
ᴠᴇʀ ʟᴏᴄᴀʟɪᴢᴀᴄ̧ᴀ̃ᴏ ᴅᴏs ᴍᴏᴅs
ᴀʀᴍᴀs ʙʟᴀᴄᴋʟɪsᴛ, ᴘᴏʀ ᴇxᴇᴍᴘʟᴏ ʀᴘɢ ᴇ ᴍɪɴɪɢᴜɴ.
ᴠᴇɪᴄᴜʟᴏs ʙʟᴀᴄᴋʟɪsᴛ, ᴘᴏʀ ᴇxᴇᴍᴘʟᴏ ʀʜɪɴᴏ.
ʟɪᴍɪᴛᴀᴅᴏʀ ᴅᴇ ᴠᴇʟᴏᴄɪᴅᴀᴅᴇ. (ʙᴇᴛᴀ)
ᴀɴᴛɪ ᴊᴇᴛᴘᴀᴄᴋ.
ᴀɴᴛɪ ғʟʏ. (ʙᴇᴛᴀ)
ʙᴀɴɪʀ ǫᴜᴇᴍ ᴀᴛɪʀᴀʀ ᴅᴇ ʀᴘɢ ᴄᴀsᴏ ᴀ ᴠᴇʀɪғɪᴄᴀᴄ̧ᴀ̃ᴏ ᴅᴇʀ ᴇʀʀᴀᴅᴏ.
ʙᴀɴɪʀ ǫᴜᴇᴍ ᴀᴛɪʀᴀʀ ᴅᴇ ᴛᴀɴǫᴜᴇ ᴄᴀsᴏ ᴀ ᴠᴇʀɪғɪᴄᴀᴄ̧ᴀ̃ᴏ ᴅᴇʀ ᴇʀʀᴀᴅᴏ.
ᴍᴏsᴛʀᴀʀ ᴛᴇʟᴀ ᴅᴏ ᴊᴏɢᴀᴅᴏʀ ɴᴀ ᴛᴇʟᴀ ᴅᴏ sᴛᴀғғ ǫᴜᴀɴᴅᴏ ᴅᴇʀ ᴀʟᴇʀᴛᴀ ᴅᴇ sᴜsᴘᴇɪᴛᴀ ᴅᴇ ᴄʜᴇᴀᴛ.
ʙᴀɴɪʀ ᴜsᴜᴀ́ʀɪᴏs ᴅᴇ ᴠʙʀ ᴄᴏᴍ sᴘᴀᴡɴ ᴅᴇ ʀʜɪɴᴏ ᴇ ʜʏᴅʀᴀ.
ᴀɴᴛɪ ʀᴇsᴏᴜʀᴄᴇ sᴛᴏᴘᴘᴇʀ.
ᴀɴᴛɪ ᴀɪᴍʙᴏᴛ. (ʙᴇᴛᴀ)
ᴘᴇʀᴍɪᴛɪʀ ᴀᴘᴇɴᴀs ᴀ ᴇɴᴛʀᴀᴅᴀ ᴅᴇ sᴛᴀғғs ᴄᴏᴍ sᴇʀɪᴀʟ ᴠᴇʀɪғɪᴄᴀᴅᴏ.
ᴡᴀʟʟʜᴀᴄᴋ ᴅᴇ sᴛᴀғғ
ʟᴏɢs ᴅᴏs ʙᴀɴs ᴇ ᴜɴʙᴀɴs
sɪsᴛᴇᴍᴀ ᴅᴇ ʙᴀɴs ɢʟᴏʙᴀɪs
ᴀɴᴛɪ ʙᴀɴ (ɴᴏᴠᴏ)
ᴠᴇʀɪғɪᴄᴀʀ ɴᴏᴠᴀs ᴀᴛᴜᴀʟɪᴢᴀᴄ̧ᴏ̃ᴇs
ᴅᴇᴛᴇᴄᴛᴀʀ ᴀʀᴍᴀ ɪɴᴠɪsɪ́ᴠᴇʟ (ʙᴇᴛᴀ)(ɴᴏᴠᴏ) [Ainda em fase de testes]
ɴᴀ̃ᴏ ᴄᴏɴsᴇɢᴜɪʀ ʀᴇᴘᴀʀᴀʀ ᴄᴀʀʀᴏ (ʙᴇᴛᴀ)(ɴᴏᴠᴏ) [Ainda em fase de testes]
ᴅᴇᴛᴇᴄᴛᴀʀ ᴅɪsᴘᴀʀᴏs ʀᴀ́ᴘɪᴅᴏs (ʙᴇᴛᴀ)(ɴᴏᴠᴏ) [Ainda em fase de testes]
ᴄᴏᴍᴀɴᴅᴏ ᴅᴇ ᴜɴʙᴀɴᴀʟʟ (ɴᴏᴠᴏ)
sɪsᴛᴇᴍᴀ ᴅᴇ ᴅᴇᴛᴇᴄᴛᴀʀ ᴊᴏɢᴀᴅᴏʀᴇs ʟɪɢᴀᴅᴏs ᴀ ᴜᴍᴀ ᴠᴘɴ (ʙᴇᴛᴀ)(ɴᴏᴠᴏ)

ᴀɴᴛɪᴄʜᴇᴀᴛ ᴘʀɪᴠᴀᴅᴏ ᴠᴇʀsᴀ̃ᴏ 1.2.17 sᴛᴀʙʟᴇ [ ᴄʀɪᴀᴅᴏ ᴘᴏʀ uW33D (ᴅɪsᴄᴏʀᴅ: uW33D#3333 | ᴅɪsᴄᴏʀᴅ ɪᴅ: 297122391580999692) ]
sᴛᴀᴛᴜs ᴅᴏ ᴀɴᴛɪᴄʜᴇᴀᴛ:  https://stats.uptimerobot.com/R0A6VFnrE2
ᴏʙs: ғᴜɴᴄ̧ᴏ̃ᴇs ᴇᴍ ʙᴇᴛᴀ ɴᴀ̃ᴏ ᴇsᴛᴀ̃ᴏ ᴀ 100%, ᴘᴏʀ ɪssᴏ ᴛᴇᴍ ᴄᴀsᴏ ǫᴜᴇ ᴘᴏᴅᴇ ᴅᴀʀ ʙᴀɴ ᴇʀʀᴀᴅᴏ, ᴏᴜ ɴᴀ̃ᴏ ғᴜɴᴄɪᴏɴᴀʀ ᴅɪʀᴇɪᴛᴏ
ᴄᴏᴍᴀɴᴅᴏs: /ᴜɴʙᴀɴᴀʟʟ, /ᴛᴏᴅᴏsᴄᴏᴍᴀɴᴅᴏs, /ᴄᴏᴍᴀɴᴅᴏs [ɴᴏᴍᴇᴅᴏᴍᴏᴅ], /ᴠᴇʀᴘᴀᴛʜ [ɴᴏᴍᴇᴅᴏᴍᴏᴅ], /ᴡᴀʟʟ, /ᴀᴄɪ [ID] (esse comando faz que o jogador esteja ignorado no binds)

]]

auth = { 
	user = "trial01", -- Nome de usuario fornecido
	key = "f8e2a1388546f9313ad7ac965a4e5990061b2d2dfd4a0e5f9b635799986fdd85" -- Chave fornecida
}

servidor = {
	sigla = "VRP",
	cor = "#ff66ff",
	acl = "Staff",
	staff = "onProt", -- Element de quando está de /staff ou /pro
	admin = "Admin", -- ACL GROUP para usar funções mais restritas
	id = "ID", -- Element de ID
	discord = "discord.gg/seuservidor", -- Discord da cidade
}

discord = { --Logs, coloque link do webhook
	aimbot = "https://discord.com/api/webhooks/XXXXXX", -- Log de suspeita de aimbot
	resourcestop = "https://discord.com/api/webhooks/XXXXXX", -- Log  ban de resource stopper
	vbrveh = "https://discord.com/api/webhooks/XXXXXX", -- Log ban de vehicle spawn com vbr cheats
	killweapon = "https://discord.com/api/webhooks/XXXXXX", -- Log ban de matar com armas blacklist
	shottank = "https://discord.com/api/webhooks/XXXXXX", -- Log ban de atirar com tanque (se tiver ativado)
	rpgvbr = "https://discord.com/api/webhooks/XXXXXX", -- Log ban de atirar com rpg que normalmente é spawn pelo vbr cheat
	flywarn = "https://discord.com/api/webhooks/XXXXXX", -- Log de aviso de suspeita de fly
	flyban = "https://discord.com/api/webhooks/XXXXXX", -- Log de ban de fly
	jetpack = "https://discord.com/api/webhooks/XXXXXX", --Log de ban de usar jetpack
	speed = "https://discord.com/api/webhooks/XXXXXX", -- Log de ban por speed hack
	vehicleblacklist = "https://discord.com/api/webhooks/XXXXXX", -- Log de ban por veiculos em lista negra (ac.veiculos)
	weaponblacklist = "https://discord.com/api/webhooks/XXXXXX", -- Log de ban por armas em lista negra (ac.armas)
	comandos = "https://discord.com/api/webhooks/XXXXXX", -- Log de comandos em resources suspeitos (retorna todos os comandos de X mod)
	binds = "https://discord.com/api/webhooks/XXXXXX", -- Log de suspeita de abrir/fechar menu
	logprotect = "https://discord.com/api/webhooks/XXXXXX", -- Log de serial não permitido entrou numa conta staff
	banimentos = "https://discord.com/api/webhooks/XXXXXX", -- Logs dos bans
	unbans = "https://discord.com/api/webhooks/XXXXXX", -- Logs dos unbans
	gbans = "https://discord.com/api/webhooks/XXXXXX", --Logs dos gbans aplicados
	updatesAC = "https://discord.com/api/webhooks/XXXXXX", -- Webhook para receber novidades do anticheat
	invisibleGun = "https://discord.com/api/webhooks/XXXXXX", -- Webhook de suspeita de arma invisivel
	fireRate = "https://discord.com/api/webhooks/XXXXXX", -- Webhook de suspeita de atirar rapido d+
}

ac = {
	armas = { -- armas blacklist
		--ID, detect, nome da arma (inventa)
		{34, true, "AWP"},
		{35, true, "RPG"},
		{36, true, "C100 RL"},
		{37, true, "Lança-chamas"},
		{38, true, "Minigun"},
	},
	veiculos = { -- veiculos blacklist
		--ID, detect
    [592] = true,
    [577] = true,
    [432] = true,
    [425] = true,
	},
	wall = {
		distancia = 350, -- Distancia max
		soid = false, -- aparecer só o ID
	},
	fly = {
		pr = 3, --aviso
		se = 5, --aviso
		te = 9999, --ban
	},
	binds = { --binds para cair no anticheat (toda a vez que o jogador clica em X tecla)
		--https://wiki.multitheftauto.com/wiki/Key_names
		{"insert", true},
		{"delete", true},
		{"end", true},
	},
	bans = { -- true ou false
		armas = true, -- banir quem usar armas blacklist
		veiculos = true, -- banir quem entrar em veiculos blacklist (mesmo desativado a função de detectar veiculos puxados pelo vbr estara ativa ex:. puxar hydra)
	},
}

outros = {
	tela = true, -- Tirar print da tela do jogador suspeito e aparecer na tela dos Staffs 
	antiss = true, -- Deixa apenas entrar no servidor gente com partilha de tela ativa (Se tiver outro mod de captura de tela desative essa opção por exemplo o meu AntiSS)
	verifyss = false, -- A cada 5mins o anticheat verifica se o jogador desativou o envio de captura de tela
	protect = false, -- Deixa apenas entrar na conta de Staff quem tiver na lista Staffs abaixo
	cooldown = 6, -- Tempo de música do ban até dar ban (1 == 1 segundo)
	musica = "https://www.myinstants.com/media/sounds/welcome-to-the-mato.mp3", -- Musica antes do ban
	bandono = true, --banir quem tentar banir os staffs com cargo de servidor.admin (ex.: Admin) [false irá apenas nao deixar o jogador ser banido]
	antivpn = { -- AntiVPN System
		ativado = false, -- quando ativo detecta se o jogador esta ligado a uma vpn se estiver dá kick
		apikey = "", -- se estiver ativo coloque sua key da api https://www.ipqualityscore.com/documentation/proxy-detection/overview [Proxy & VPN Detection API]
		logchute = "não funciona ainda", -- em manutenção 
		iplevel = "não funciona ainda", -- em manutenção
		banir = false, -- em manutenção - não funciona ainda
	},
	update = true, -- receber atualizações do anticheat » Pasta Updates se tiver uma versão recente faça a troca de versões. [Quando está desativado a nova atualização não é baixada automaticamente]
	chat = true, -- aparece mensagem no chat quando dá start no anticheat
	globalban = true, --[[
	Sistema de banimento global o que é?
	Este sistema faz sincronização com outros servidores e guarda o ban aplicado por o mesmo anticheat no servidor1 e se o jogador xitado tentar se conectar
	ao servidor2 não irá conseguir pois o Serial e IP do mesmo está numa lista negra do anticheat. 
	]]
}

staffs = {  -- Apenas colocar serial se outros » protect estiver true (Pegar seu serial dê f8 e digite serial)
	-- caso não tiver deixe padrão como está ou comente/delete "Serial",
	"Serial", -- Serial do staff 
	"Serial", -- Serial do staff 
	"Serial", -- Serial do staff 
}

antibanjogadores = { -- Colocar serials que não podem ser banidos (Pegar seu serial dê f8 e digite serial)
	-- caso não tiver deixe padrão como está ou comente/delete ["Serial"] = true,
	["Serial"] = true, -- Serial do staff 
	["Serial"] = true, -- Serial do staff 
	["Serial"] = true, -- Serial do staff 
}

-- Notify info (não apagar) [tipos usados warning & info]
notify = function(player, message, type)
    exports["vrp_info"]:addBox(player, message, type)
    --exports["vrp_info"]:addBox(player, message, "info")
end
