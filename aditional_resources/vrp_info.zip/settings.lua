
settings = {
    notificationResource = {
        types = {
            ["success"] = {
                sound = {
                    raw = "https://cdn.discordapp.com/attachments/1040855043089375282/1048366462626177095/w.mp3";
                    volume = 0.04;
                };
                color = tocolor(78, 221, 93, 255);
                opacity = 0.96;
                time = 11;
                typeName = "SUCESSO";
                preference = false;
            };
            ["error"] = {
                sound = {
                    raw = "https://cdn.discordapp.com/attachments/1040855043089375282/1048366462626177095/w.mp3";
                    volume = 0.04;
                };
                color = tocolor(255, 97, 97, 255);
                opacity = 0.96;
                time = 11;
                typeName = "ERRO";
                preference = false;
            };
            ["info"] = {
                sound = {
                    raw = "https://cdn.discordapp.com/attachments/1040855043089375282/1048366462626177095/w.mp3";
                    volume = 0.04;
                };
                color = tocolor(97, 160, 255, 255);
                opacity = 0.96;
                time = 11;
                typeName = "INFORMAÇÃO";
                preference = false;
            };
            ["staff"] = {
                sound = {
                    raw = "https://cdn.discordapp.com/attachments/1040855043089375282/1048366462626177095/w.mp3";
                    volume = 0.04;
                };
                color = tocolor(197, 179, 123, 255);
                opacity = 0.96;
                time = 16;
                typeName = "STAFF";
                preference = false;
            };
            ["dica"] = {
                sound = {
                    raw = "https://cdn.discordapp.com/attachments/1040855043089375282/1048366462626177095/w.mp3";
                    volume = 0.04;
                };
                color = tocolor(235, 252, 3, 255);
                opacity = 0.96;
                time = 21;
                typeName = "DICA";
                preference = false;
            };
            ["warning"] = {
                sound = {
                    raw = "https://cdn.discordapp.com/attachments/1040855043089375282/1048366462626177095/w.mp3";
                    volume = 0.04;
                };
                color = tocolor(252, 144, 3, 255);
                opacity = 0.96;
                time = 11;
                typeName = "AVISO";
                preference = false;
            };
        };
    };
};