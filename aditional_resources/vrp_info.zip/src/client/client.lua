function addBox(message, type)
    triggerEvent('addBox', localPlayer, message, type);
end