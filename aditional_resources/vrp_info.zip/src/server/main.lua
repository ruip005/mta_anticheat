function addBox (player, message, type)
    if isElement (player) and (message) and (type) then 
        triggerClientEvent (player, 'addBox', player, message, type);
    end 
end
addEvent('addBox', true)
addEventHandler('addBox', root, addBox)

outputDebugString('['..getResourceName (getThisResource ( ))..'] | Notification System started successfully.', 4, 197, 179, 123)