addEventHandler("onClientPlayerDamage", root, 
function ()
    if getElementData(source, "onProt") then 
        cancelEvent()
    end 
end)

addEventHandler("onClientPlayerStealthKill", localPlayer, 
function (thePlayer)
    if getElementData(thePlayer, "onProt") then 
        cancelEvent()
    end 
end)