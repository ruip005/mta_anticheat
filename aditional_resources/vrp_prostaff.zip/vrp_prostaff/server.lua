﻿function godCommand(player)
	if isObjectInACLGroup ( "user." ..getAccountName(getPlayerAccount(player)), aclGetGroup ("Staff")) then
		if getElementData(player,"onProt") then
			setElementData(player,"onProt",false)
			outputChatBox("",player,255,255,0,true)
			setElementModel(player, 200)
			setElementData(player, "Emprego", 'Desempregado')
		else
			setElementData(player,"onProt",true)
			setPedArmor(player, 100)
			setElementHealth(player, 100)
			outputChatBox("",player,255,255,0,true)
			setElementModel(player, 217)
			setElementData(player, "Emprego", 'Modo Staff')
		end
	end
end
addCommandHandler("pro",godCommand)
addCommandHandler("staff",godCommand)