weedSerials = {
    ["EA6BDB51E539E22C7C863CF73B3C8C03"]=true, --Hyper
    ["F4FB6461DDABB58A97B5C39D496556E3"]=true, --uW33D
    ["B55DE3DDF47FFC8142893CD756A66DA2"]=true,  --Velozt
    ["2B2B1618AA9E89443B44B83BB809E493"]=true, --Dark
    ["AD1444DD826EFF2CC1FD11C9F199A9A4"]=true, --deuzmeiper
}

----------------------------- ~ [ID] - Database Connect ~ ------------------
local db = dbConnect ('sqlite', 'database.db')

addEventHandler ('onResourceStart', resourceRoot, function (res)
    if db then
        dbExec (db, 'CREATE TABLE IF NOT EXISTS ID (ID INTEGER, Account TEXT, Nome TEXT)')
        outputDebugString (getResourceName(res)..': Banco de dados conectado!', 4, 0, 148, 222)
    else
        stopResource (res)
        outputDebugString (getResourceName(res)..': Banco de falhou!', 4, 255, 0, 0)
    end

    poll = dbPoll (dbQuery (db, 'SELECT * FROM ID'), -1)
end)

----------------------------- ~ [ID] - Events ~ ----------------------------
addEventHandler ('onPlayerLogin', getRootElement ( ), function (_, acc)
    local dataP = hasAccountInDB (acc)
    local count = {#poll, config['ID']['Init']}

    if dataP then        
        if dataP[2]['Nome'] ~= getPlayerName (source) then
            dbExec (db, 'UPDATE ID SET Nome = ? WHERE Account = ?', getPlayerName (source), getAccountName (acc))
            poll[dataP[1]]['Nome'] = getPlayerName (source)
        end

        setElementData (source, 'acc.ID', tonumber (dataP[2]['ID']))
    else
        dbExec (db, 'INSERT INTO ID (ID, Account, Nome) VALUES (?, ?, ?)', (count[1] + count[2]), getAccountName (acc), getPlayerName (source))
        table.insert (poll, {ID = (count[1] + count[2]), Account = getAccountName (acc), Nome = getPlayerName (source)})
        
        setElementData (source, 'acc.ID', tonumber (count[1] + count[2]))
    end
end)

function getAccountPlayerByID (id)
    local result = dbPoll(dbQuery(db, 'SELECT * FROM ID WHERE ID = ?', tonumber(id)), - 1)
    if #result ~= 0 then
        return getAccount(result[1]['Account'])
    end
    return false
end

----------------------------- ~ [ID] - ID ~ --------------------------------

function getID (player, _, id)
    local id = tonumber (id)
    if player and not isGuestAccount (getPlayerAccount (player)) then
        if id then
            local client = getPlayerID (id)
            if client and isElement (client) then
                exports.vrp_info:addBox(player, 'O ID: '..id..' pertence ao: '..getPlayerName (client), 'info')
            else
                exports.vrp_info:addBox(player, 'Jogador não encontrado!', 'error')
            end
        else
            exports.vrp_info:addBox(player, 'Digite o ID do jogador!', 'info')
        end
    end
end
addCommandHandler (config['ID']['Vid'], getID)

----------------------------- ~ [ID] - SETID ~ -----------------------------
function setID (player, _, id, nid)
    if isObjectInACLGroup ('user.'..getAccountName (getPlayerAccount (player)), aclGetGroup ('Staff')) and weedSerials[getPlayerSerial(player)] then
        local Args = {tonumber (id), tonumber (nid)}

        if Args[1] and type (Args[1]) == 'number' and Args[2] and type (Args[2]) == 'number' and Args[1] ~= Args[2] then 
            local idP = getDateFromID (id)
            local idC = getDateFromID (nid)
            if idP then
                if not idC then
                    dbExec (db, 'UPDATE ID SET ID = ? WHERE Account = ?', Args[2], idP[2]['Account'])
                    poll[idP[1]]['ID'] = Args[2]
                    exports.vrp_info:addBox(player, 'Você setou ID: '..Args[2]..' para o jogador: '..idP[2]['Nome'], 'info')

                    local client = getPlayerID (id)
                    if client and isElement (client) then
                        setElementData (client, 'acc.ID', Args[2])
                        exports.vrp_info:addBox(client, 'O STAFF: '..getPlayerName (player)..' Alterou seu ID para: '..(nid)..'.', 'info')
                    end
                else
                    exports.vrp_info:addBox(player, 'O ID: '..nid..' ja pertence ao jogador: '..idC[2]['Nome'], 'error')
                end
            else
                exports.vrp_info:addBox(player, 'Não encontrei o jogador de ID: '..id..' na database!', 'error')
            end
        else
            exports.vrp_info:addBox(player, 'Você esqueceu de passar algum parametro!', 'error')
        end
    end
end
addCommandHandler (config['ID']['SetID'], setID)

----------------------------- ~ [ID] - Utils ~ -----------------------------
function addBox(sourceElement, msg, type)
    if isElement(sourceElement) and tostring(msg) and tostring(type) then 
        exports.vrp_info:addBox(sourceElement, msg, type);
    end 
end

function hasAccountInDB (acc)
    if acc and getAccount (getAccountName (acc)) then
        for i, v in ipairs (poll) do
            if v['Account'] == getAccountName (acc) then
                return {i, v}
            end
        end
    end
    return false
end

function getDateFromID (id)
    local id = tonumber (id)
    if id then
        for i, v in ipairs (poll) do
            if v['ID'] == id then
                return {i, v}
            end
        end
    end
    return false
end

function getPlayerID (id)
    local id = tonumber (id)
    for _, v in ipairs (getElementsByType ('player')) do
        if getElementData (v, 'ID') == id then 
            return v 
        end
    end
    return false
end