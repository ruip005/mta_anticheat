local drawDistance = 20
local isPlayerIdVisible = true
g_StreamedInPlayers = {}
voiceOn = {}

function onVoice()
  if source ~= localPlayer then
    if isElementStreamedIn(source) then
      voiceOn[source] = true
    else
      voiceOn[source] = nil
    end
  end
end
addEventHandler("onClientPlayerVoiceStart", root, onVoice)

function offVoice()
  if source ~= localPlayer then
    voiceOn[source] = nil
  end
end
addEventHandler("onClientPlayerVoiceStop", root, offVoice)

function onClientRender()
  local cx, cy, cz, lx, ly, lz = getCameraMatrix()
  for k, player in pairs(g_StreamedInPlayers) do
    if isElement(player) and isElementStreamedIn(player) then
      do
        local vx, vy, vz = getPedBonePosition(player, 4)
        local dist = getDistanceBetweenPoints3D(cx, cy, cz, vx, vy, vz)
        if dist < drawDistance and isLineOfSightClear(cx, cy, cz, vx, vy, vz, true, false, false) then
          local x, y = getScreenFromWorldPosition(vx, vy, vz + 0.3)
          if x and y then
            local ID = getElementData(player, "ID") or "N/A"
            if (getElementAlpha(player) > 0) then
            local w = dxGetTextWidth(ID, 0.1, "default")
            local h = dxGetFontHeight(1, "default")
            if voiceOn[player] then
                color = tocolor(0, 255, 119)
              else
                color = tocolor(255, 255, 255, 255)
            end
            if (isPlayerIdVisible) then
                if (getElementData(player, 'onProt') == true) then
                  dxDrawText("("..ID..") STAFF", x - 1 - w / 1 + 1, y - 1 - h - 2 + 1, (w + x - 1 - w / 1 + 1), (h + y - 1 - h - 2 + 1), tocolor(0, 0, 0, getElementAlpha(player)), 1.20, "default", "center", "center", false, false, false, false, false)
                  dxDrawText("("..ID..") #4F9ACCSTAFF", x - 1 - w / 1, y - 1 - h - 2, (w + x - 1 - w / 1), (h + y - 1 - h - 2), color, 1.20, "default", "center", "center", false, false, false, true, false)
                else
                  dxDrawText("("..ID..")", x - 1 - w / 1 + 1, y - 1 - h - 2 + 1, (w + x - 1 - w / 1 + 1), (h + y - 1 - h - 2 + 1), tocolor(0, 0, 0, getElementAlpha(player)), 1.20, "default", "center", "center", false, false, false, false, false)
                  dxDrawText("("..ID..")", x - 1 - w / 1, y - 1 - h - 2, (w + x - 1 - w / 1), (h + y - 1 - h - 2), color, 1.20, "default", "center", "center", false, false, false, false, false)  
                end
            end
            end
          end
        end
      end
    else
      table.remove(g_StreamedInPlayers, k)
      voiceOn[player] = nil
    end
  end
end
addEventHandler("onClientRender", root, onClientRender)

function onClientElementStreamIn()
  if getElementType(source) == "player" and source ~= getLocalPlayer() then
    setPlayerNametagShowing(source, false)
    table.insert(g_StreamedInPlayers, source)
  end
end
addEventHandler("onClientElementStreamIn", root, onClientElementStreamIn)

function onClientResourceStart(startedResource)
  visibleTick = getTickCount()
  counter = 0
  local players = getElementsByType("player")
  for k, v in pairs(players) do
    if isElementStreamedIn(v) and v ~= getLocalPlayer() then
      setPlayerNametagShowing(v, false)
      table.insert(g_StreamedInPlayers, v)
    end
  end
end
addEventHandler("onClientResourceStart", resourceRoot, onClientResourceStart)

function toggleID()
  isPlayerIdVisible = not (isPlayerIdVisible)
end
addEvent("togglePlayerIDVisible", true)
addEventHandler("togglePlayerIDVisible", root, toggleID)
