config = {
    ['ID'] = {
        ['Init'] = 50; --// ID Inicial!
        ['Vid'] = 'id'; --// Comando que será ultilzado para saber a que jogador pertecence o ID!
        ['SetID'] = 'setid'; --// Comando que será ultilizado para setar id! /setid [ID] [NOVO_ID] 
    };

    ['Infobox'] = 'addBox'; --// Evento da sua infobox!
}